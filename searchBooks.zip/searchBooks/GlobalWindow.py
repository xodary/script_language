from tkinter import *
window = Tk()
window.title('read a book')
window.geometry('1920x1080')
width = 1920
height = 1080

book = None
myBookList = [[],[],[]]
mark = 0