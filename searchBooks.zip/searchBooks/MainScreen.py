import framework
import SearchFramework
import GlobalWindow

framework.run(SearchFramework)

